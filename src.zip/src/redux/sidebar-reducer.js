let initialState = {};

const sidebarReducer = (state = initialState, action) => {
    return state;
}

export default sidebarReducer;